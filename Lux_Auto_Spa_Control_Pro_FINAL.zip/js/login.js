import { signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { auth } from "./firebase-config.js";

const form = document.getElementById("loginForm");
const msg = document.getElementById("loginMessage");

form?.addEventListener("submit", async (e) => {
  e.preventDefault();
  msg.textContent = "Ingresando...";
  try{
    await signInWithEmailAndPassword(auth, email.value.trim(), password.value.trim());
    msg.textContent = "Ingreso correcto.";
    window.location.href = "panel.html";
  }catch(err){
    console.error(err);
    msg.textContent = "Correo o contraseña incorrectos.";
  }
});

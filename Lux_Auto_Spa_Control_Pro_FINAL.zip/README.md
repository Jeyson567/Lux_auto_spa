# Lux Auto Spa Control Pro

Versión compacta y funcional del sistema.

## Incluye
- Login con Firebase Auth
- Roles admin / empleado
- Dashboard
- Clientes
- Vehículos múltiples
- Catálogo de servicios
- Registro de servicios con suma de puntos
- Suscripciones mensuales con días por vencer
- Pagos
- Recompensas
- Objetivos
- Canjes
- Usuarios internos
- Reportes
- Configuración
- Portal cliente
- WhatsApp con mensajes listos

## Firebase
Activa:
- Authentication > Email/Password
- Firestore Database

## Reglas temporales
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

## Colecciones usadas
- usuarios
- clientes
- catalogo_servicios
- servicios
- suscripciones
- pagos
- recompensas
- objetivos
- canjes
- auditoria
- alertas
- configuracion

## Perfil admin
Primero crea el usuario en Firebase Authentication.
Luego agrega en Firestore colección `usuarios` un documento así:

{
  "nombre": "Tu Nombre",
  "correo": "tu_correo_admin",
  "rol": "admin",
  "activo": true
}

## Nota sobre WhatsApp
Desde la web el mensaje se abre listo en WhatsApp Web o la app.
No se puede enviar automáticamente sin intervención del usuario desde una web normal.
